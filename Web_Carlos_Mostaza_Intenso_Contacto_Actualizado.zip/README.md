# Carlos Cuestas Ayllón — Scientific website

Bilingual (ES/EN) GitHub Pages website with the elegant mustard palette.

## Publish
Upload the **contents** of this folder to the root of the `main` branch (not the ZIP). Replace `index.html`, and retain the `cv/` and `images/` directories.

## Edit texts
Open `index.html` and find `const data=`. All bilingual text is stored in the `es` and `en` sections. To edit colors, find the CSS variables near `:root`.

Colors: `#D5A52C`, `#F8F5EC`, `#292929`, `#FFFFFF`.

LinkedIn currently links to a profile search until the exact public profile URL is supplied.

Actualización: contacto con correo institucional, personal y teléfono en ES/EN.
