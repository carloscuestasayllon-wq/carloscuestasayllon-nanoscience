# Carlos Cuestas Ayllón — Web científica / Scientific website

Web personal bilingüe (ES/EN), publicada con GitHub Pages.

## Publicación
Sube **todos los archivos y carpetas del ZIP** a la raíz de la rama `main`, conservando las carpetas `cv/` e `images/`. El archivo `index.html` debe quedar en la raíz.

## Modificaciones
Edita `index.html` para cambiar textos y enlaces; sustituye los archivos de `cv/` para actualizar los currículos. Las ilustraciones científicas originales están en `images/`.

**LinkedIn:** se ha incluido un enlace de búsqueda, no un perfil personal verificado. Sustitúyelo por la URL exacta de tu perfil cuando la facilites.

**Imágenes:** son ilustraciones científicas originales, no micrografías reales. Se pueden sustituir por fotografías autorizadas del laboratorio.
